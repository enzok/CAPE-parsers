def extract_config():
    pass
